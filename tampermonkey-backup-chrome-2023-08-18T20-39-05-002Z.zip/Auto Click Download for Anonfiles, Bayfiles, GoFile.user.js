// ==UserScript==
// @name         Auto Click Download for Anonfiles, Bayfiles, GoFile
// @namespace    https://cracked.io/Faramir
// @version      0.2
// @description  Auto click download button.
// @author       Faramir
// @license      MIT
// @match        *://anonfiles.com/*
// @match        *://bayfiles.com/*
// @match        *://gofile.io/*
// @icon         https://www.google.com/s2/favicons?sz=64&domain=anonfiles.com
// @run-at       document-end
// ==/UserScript==
const interval = setInterval(() => {
    const element = document.querySelector('#download-url, a[href*="download"]');
    if (element) {
        element.click();
        clearInterval(interval);
    }
}, 500);