// ==UserScript==
// @name         Facebook - All "See more" buttons expanded
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  Facebook - All the "See more" buttons expanded on scroll - support english, italian 'Altro...', español 'Ver más', français 'Afficher la suite', deutsch 'Mehr ansehen'
// @author       ClaoDD
// @match        https://www.facebook.com/*
// @grant        none
// ==/UserScript==

(window.onscroll = function(){
const links = Array.from(document.querySelectorAll('.oajrlxb2'));
links.forEach((link) => {
  if (link.textContent === 'Altro...' || link.textContent === 'See more' || link.textContent === 'Ver más' || link.textContent === 'Afficher la suite' || link.textContent === 'Mehr ansehen')  {
    link.click();
  }
})
                             })();